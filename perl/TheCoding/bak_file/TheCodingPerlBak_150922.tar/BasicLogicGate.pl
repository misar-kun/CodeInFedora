#!/usr/bin/perl 

use strict;
use warnings;
use 5.010;

####### BASIC PRINT FUNCTION REALISE #######
sub IsParameterGeNum {
	my $Num = shift @_;
	return 1 if @_ >= $Num;
	say "Parameter Too Few.";
	return 0;
}


####### LOGIC FUNCTION REALISE #######

sub AND {
	&IsParameterGeNum(2, @_) or die "Error Logic Gate <AND/NAND> of \"@_\". Please Check\n";
	foreach (@_) {
		return 0 if $_ ~~ 0;
		next if $_ ~~ 1;
		die "Parameter Error at Logic Gate <AND/NAND> is $_. Please Check\n";
	}
return 1;

}

sub NAND {
	my $ANDRet = &AND(@_);
	return 0 if $ANDRet ~~ 1;
	return 1;
}

sub OR {
	foreach (@_) {
		return 1 if $_ ~~ 1;
		next if $_ ~~ 0;
		die "Parameter Error at Logic Gate <OR/NOR> is $_. Please Check\n";
	}
	return 0;
}

sub NOR {
	my $ORRet = &OR(@_);
	return 0 if $ORRet ~~ 1;
	return 1;
}

sub NOT {
	my @RetTable;
	foreach (@_) {
		if ($_ ~~ 1) {
			push @RetTable, 0;
		} elsif ($_ ~~ 0) {
			push @RetTable, 1;
		} else {
			die "Parameter Error at Logic Gate <NOT> is $_. Please Check\n";
		}
	}
	return @RetTable;
}

sub BUFF {
	return @_
}

sub XOR {
	die "To Much Parameter for Logic Gate <XOR/XNOR> of \"@_\". Please Check\n" if (@_ > 2);
	my $GateTmp1 = &OR(@_);
	my $GateTmp2 = &NAND(@_);
	return &AND($GateTmp1, $GateTmp2);
}

sub XNOR {
	return (1 - &XNOR(@_));
}

####### Basic Combinational Logic Circuit #######
sub HalfAdder {
	#Input: (A, B)
	#Output: (Carry, Sum)
	my @RetTable;
	push @RetTable, &AND(@_);
	push @RetTable, &XOR(@_);
	return @RetTable;
}

sub FullAdder {
	#Input: (A, B, CarryIn)
	#Output: (CarryOut, Sum)
	my($A, $B, $CarryIn) = @_;
	my ($HalfAdderCarry1, $HalfAdderSum) = &HalfAdder($A, $B);
	my ($HalfAdderCarry2, $Sum) = &HalfAdder($HalfAdderSum, $CarryIn);
	my $CarryOut = &OR($HalfAdderCarry1, $HalfAdderCarry2);
	return ($CarryOut, $Sum);
}

sub Add {
	die "Error <Add> Input ParaLen Should Equal!!\n" if @_ % 2;
	my $SplitLocation = @_ / 2;
	my @AdderB = splice @_, $SplitLocation;
	my @AdderA = @_;
	my ($Carry, $Sum) = (0, 0);
	my @AdderRet;
	for (1..$SplitLocation) {
		($Carry, $Sum) = &FullAdder(pop @AdderA, pop @AdderB, $Carry);
		unshift @AdderRet, $Sum;
	}
	unshift @AdderRet, $Carry;
	return @AdderRet;
}
	 
####### Basic Sequential Logic Circuit #######


######## TEST FUNCTION #######
#my @Test1 = qw /1 1/;
#my @Test2 = qw /0 0/;
#my @Test3 = qw /0 1/;
#my @Test4 = qw /a b/;
#
#my $LogicRet;
#my @Test;
#
#say "--- AND TEST ---";
#@Test = @Test1;
#$LogicRet = &AND(@Test);
#say "@Test is $LogicRet";
#@Test = @Test2;
#$LogicRet = &AND(@Test);
#say "@Test is $LogicRet";
#@Test = @Test3;
#$LogicRet = &AND(@Test);
#say "@Test is $LogicRet";
##@Test = @Test4;
##$LogicRet = &AND(@Test);
##say "@Test is $LogicRet";
#
#say "--- NAND TEST ---";
#@Test = @Test1;
#$LogicRet = &NAND(@Test);
#say "@Test is $LogicRet";
#@Test = @Test2;
#$LogicRet = &NAND(@Test);
#say "@Test is $LogicRet";
#@Test = @Test3;
#$LogicRet = &NAND(@Test);
#say "@Test is $LogicRet";
##@Test = @Test4;
##$LogicRet = &NAND(@Test);
##say "@Test is $LogicRet";
#
#say "--- OR TEST ---";
#@Test = @Test1;
#$LogicRet = &OR(@Test);
#say "@Test is $LogicRet";
#@Test = @Test2;
#$LogicRet = &OR(@Test);
#say "@Test is $LogicRet";
#@Test = @Test3;
#$LogicRet = &OR(@Test);
#say "@Test is $LogicRet";
##@Test = @Test4;
##$LogicRet = &OR(@Test);
##say "@Test is $LogicRet";
#
#say "--- NOR TEST ---";
#@Test = @Test1;
#$LogicRet = &NOR(@Test);
#say "@Test is $LogicRet";
#@Test = @Test2;
#$LogicRet = &NOR(@Test);
#say "@Test is $LogicRet";
#@Test = @Test3;
#$LogicRet = &NOR(@Test);
#say "@Test is $LogicRet";
##@Test = @Test4;
##$LogicRet = &NOR(@Test);
##say "@Test is $LogicRet";
