#!/usr/bin/perl 

use strict;
use warnings;
use 5.010;
do 'BasicLogicGate.pl';


my @AddA = qw /0 0 1 0/;
my @AddB = qw /0 1 1 0/;
&Add(@AddA, @AddB);
