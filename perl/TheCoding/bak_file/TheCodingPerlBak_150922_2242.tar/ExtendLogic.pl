#!/usr/bin/perl 

use strict;
use warnings;
use 5.010;
do 'BasicLogicGate.pl';
do 'BasicFunction.pl';

my @A = qw /0 0 1/;
my @RsRet = &RS_Triger(@A);
say "@RsRet";

say "-----------------";
for (0..7) {
	my @Input = &dec2bin($_, 3);
	my @Output = &RS_Triger(@Input);
	say "@Input <--> @Output";
}

say "-----------------";
my @Input1 = &dec2bin(-37, 10);
my @Input2 = &dec2bin(-237, 10);
my @Ret = &Add(@Input1, @Input2);
say "@Ret";
my $RetVal = &bin2dec(@Ret, 's');
say $RetVal;
