#!/usr/bin/perl 

use strict;
use warnings;
use 5.010;
do 'BasicLogicGate.pl';


my @Test = qw /1 1/;
my $LogicRet;

$LogicRet = &AND(@Test);
say "@Test is $LogicRet";
