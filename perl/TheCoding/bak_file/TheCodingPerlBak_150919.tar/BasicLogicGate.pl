#!/usr/bin/perl 

use strict;
use warnings;
use 5.010;

####### LOGIC FUNCTION REALISE #######

sub AND {
	foreach (@_) {
		return 0 if $_ ~~ 0;
		next if $_ ~~ 1;
		die "Parameter Error at Logic Gate <AND/NAND> is $_. Please Check\n";
	}
return 1;

}

sub NAND {
	my $ANDRet = &AND(@_);
	return 0 if $ANDRet ~~ 1;
	return 1;
}

sub OR {
	foreach (@_) {
		return 1 if $_ ~~ 1;
		next if $_ ~~ 0;
		die "Parameter Error at Logic Gate <OR/NOR> is $_. Please Check\n";
	}
	return 0;
}

sub NOR {
	my $ORRet = &OR(@_);
	return 0 if $ORRet ~~ 1;
	return 1;
}







######## TEST FUNCTION #######
#my @Test1 = qw /1 1/;
#my @Test2 = qw /0 0/;
#my @Test3 = qw /0 1/;
#my @Test4 = qw /a b/;
#
#my $LogicRet;
#my @Test;
#
#say "--- AND TEST ---";
#@Test = @Test1;
#$LogicRet = &AND(@Test);
#say "@Test is $LogicRet";
#@Test = @Test2;
#$LogicRet = &AND(@Test);
#say "@Test is $LogicRet";
#@Test = @Test3;
#$LogicRet = &AND(@Test);
#say "@Test is $LogicRet";
##@Test = @Test4;
##$LogicRet = &AND(@Test);
##say "@Test is $LogicRet";
#
#say "--- NAND TEST ---";
#@Test = @Test1;
#$LogicRet = &NAND(@Test);
#say "@Test is $LogicRet";
#@Test = @Test2;
#$LogicRet = &NAND(@Test);
#say "@Test is $LogicRet";
#@Test = @Test3;
#$LogicRet = &NAND(@Test);
#say "@Test is $LogicRet";
##@Test = @Test4;
##$LogicRet = &NAND(@Test);
##say "@Test is $LogicRet";
#
#say "--- OR TEST ---";
#@Test = @Test1;
#$LogicRet = &OR(@Test);
#say "@Test is $LogicRet";
#@Test = @Test2;
#$LogicRet = &OR(@Test);
#say "@Test is $LogicRet";
#@Test = @Test3;
#$LogicRet = &OR(@Test);
#say "@Test is $LogicRet";
##@Test = @Test4;
##$LogicRet = &OR(@Test);
##say "@Test is $LogicRet";
#
#say "--- NOR TEST ---";
#@Test = @Test1;
#$LogicRet = &NOR(@Test);
#say "@Test is $LogicRet";
#@Test = @Test2;
#$LogicRet = &NOR(@Test);
#say "@Test is $LogicRet";
#@Test = @Test3;
#$LogicRet = &NOR(@Test);
#say "@Test is $LogicRet";
##@Test = @Test4;
##$LogicRet = &NOR(@Test);
##say "@Test is $LogicRet";
